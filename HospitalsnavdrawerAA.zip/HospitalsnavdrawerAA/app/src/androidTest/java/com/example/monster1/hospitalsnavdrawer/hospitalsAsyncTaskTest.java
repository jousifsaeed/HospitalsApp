package com.example.monster1.hospitalsnavdrawer;

import static org.junit.Assert.*;

/**
 * Created by negmpc on 12/06/2018.
 */
public class hospitalsAsyncTaskTest {

}