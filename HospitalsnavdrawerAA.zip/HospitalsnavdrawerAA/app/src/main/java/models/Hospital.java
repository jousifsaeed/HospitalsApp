package models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

public class Hospital implements Serializable {
    private String name;
    private String email;
    private int beds ;
    private int  doctors;
    private int  nurses;
    private String   contact_data ;
    private String    map_link;
    private String   created_at;
    private String  updated_at;
    private ArrayList<Section> sections;
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getBeds() {
        return beds;
    }

    public void setBeds(int beds) {
        this.beds = beds;
    }

    public int getDoctors() {
        return doctors;
    }

    public void setDoctors(int doctors) {
        this.doctors = doctors;
    }

    public int getNurses() {
        return nurses;
    }

    public void setNurses(int nurses) {
        this.nurses = nurses;
    }

    public String getContact_data() {
        return contact_data;
    }

    public void setContact_data(String contact_data) {
        this.contact_data = contact_data;
    }

    public String getMap_link() {
        return map_link;
    }

    public void setMap_link(String map_link) {
        this.map_link = map_link;
    }

    public String getCreated_at() {
        return created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }

    public String getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(String updated_at) {
        this.updated_at = updated_at;
    }
    public ArrayList<Section> getSections(){
        return sections;
    }
    public static Hospital generateHospital(){
        Random rand = new Random();
        int value = rand.nextInt(50);


        Hospital h = new Hospital();
        h.name = "Name " + value;
        h.beds = value - 5;
        h.nurses = value+ 2;
        h.doctors = 23;
        h.map_link = "Http:www.google.com";
        h.contact_data = "COntact ";
        h.sections = new ArrayList<Section>();
        h.sections.add(Section.generateSection());
        h.sections.add(Section.generateSection());


        return h;
    }
}
