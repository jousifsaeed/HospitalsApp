package com.example.monster1.hospitalsnavdrawer;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import models.Hospital;

public class Hos0 extends AppCompatActivity {

    TextView hosname;
    TextView contact_data;
    int docs;
    int nurses;
    int beds;
    Button call;
    Button maps;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hospital_inner_view);
        Hospital hospital = (Hospital)getIntent().getSerializableExtra("Hospital");
        hosname = (TextView) findViewById(R.id.hosname);
        hosname.setText(hospital.getName());
        contact_data=findViewById(R.id.contact_data);
        contact_data.setText(hospital.getContact_data());


    }
}

