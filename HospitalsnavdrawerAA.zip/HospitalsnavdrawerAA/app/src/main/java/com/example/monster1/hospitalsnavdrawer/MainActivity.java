package com.example.monster1.hospitalsnavdrawer;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import models.Hospital;

import static com.example.monster1.hospitalsnavdrawer.MainActivity.HOSPITALS_REQUEST_URL;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {



    ArrayList<Hospital> hospitals;
    ListView listView;
    /**
     * URL to get hospitals information
     */

    public static final String HOSPITALS_REQUEST_URL = "https://api.myjson.com/bins/zc3wu";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        listView =findViewById(R.id.idListView);

        hospitals = new ArrayList<Hospital>();
        hospitals.add(Hospital.generateHospital());
        hospitals.add(Hospital.generateHospital());
        hospitals.add(Hospital.generateHospital());
        MyAdapter adapter= new MyAdapter(getApplicationContext(),hospitals);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                Hospital hospitalToPass = hospitals.get(position);

                Intent myIntent = new Intent(view.getContext(),Hos0.class);
                myIntent.putExtra("Hospital",hospitalToPass);
                startActivityForResult(myIntent,0);


                }
        });

    }

    boolean bp=false;
    @Override
    public void onBackPressed() {

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }


    }



    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();


        if (id == R.id.set) {
            Toast.makeText(this, "Settings Clicked!", Toast.LENGTH_LONG).show();
            return true;

        } else if (id == R.id.about) {
            Toast.makeText(this, "About Clicked!", Toast.LENGTH_LONG).show();
            return true;

        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}



class MyAdapter extends ArrayAdapter{
    ArrayList<Hospital> hospitals;

    public MyAdapter(Context context, ArrayList<Hospital> hospitals) {
        super(context,R.layout.listviewmain,R.id.idTitle,hospitals);
        this.hospitals = hospitals;
    }
    @Nullable
    @Override
    public View getView(int position, View convertView, ViewGroup parent){

        LayoutInflater inflater= (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View row= inflater.inflate(R.layout.listviewmain,parent,false);
        TextView myTitle= row.findViewById(R.id.idTitle);
        TextView myDescription= row.findViewById(R.id.idDescription);


        myTitle.setText(hospitals.get(position).getName());

        myDescription.setText(hospitals.get(position).getContact_data());

       /* ..................... */
       

        return row;
    }

 }
     // creat hospialsAsyncTs

    /* class hospitalsAsyncTask extends AsyncTask<URL, Void, String> {
       String data = "";
       String singleParsed = "";
       String dataParseed = "";
         @Override
         protected String doInBackground(URL... urls) {
             try {
                 URL url = new URL(HOSPITALS_REQUEST_URL);
                 HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                 httpURLConnection.setRequestMethod("GET");
                 httpURLConnection.setDoOutput(true);
                 httpURLConnection.setConnectTimeout(5000);
                 httpURLConnection.setReadTimeout(5000);
                 httpURLConnection.connect();
                 InputStream inputStream  = httpURLConnection.getInputStream();
                 BufferedReader bufferedReader  = new BufferedReader(new InputStreamReader(inputStream));
                 String line = "";
                 while (line != null){
                     line = bufferedReader.readLine();
                     data = data + line +"\n";
                 }
                 JSONArray hospitalsJsonArray = new JSONArray();
                 for(int i = 0 ; i < hospitalsJsonArray.length() ;i++){
                     try {
                         JSONObject hospitalsJsonObject =(JSONObject) hospitalsJsonArray.get(i);
                         singleParsed = "ID : " + hospitalsJsonObject.get("id")+ "\n" +
                                        "Name : " + hospitalsJsonObject.get("name")+ "\n" +
                                        "E-mail: " + hospitalsJsonObject.get("email")+ "\n" +
                                        "Beds : " + hospitalsJsonObject.get("beds")+ "\n" +
                                        "Doctors : " + hospitalsJsonObject.get("doctors")+ "\n" +
                                        "Nurses : " + hospitalsJsonObject.get("nurses")+ "\n" +
                                        "Contact_data : " + hospitalsJsonObject.get("contct_data")+ "\n" +
                                        "Map_link : " + hospitalsJsonObject.get("map_link")+ "\n" +
                                        "Created_at : " + hospitalsJsonObject.get("created_at")+ "\n" +
                                        "Updated_at : " + hospitalsJsonObject.get("updated_at")+ "\n" +
                                        "Sections : " + hospitalsJsonObject.get("sections")+ "\n" ;
                         dataParseed = dataParseed + singleParsed;


                     } catch (JSONException e) {
                         e.printStackTrace();
                     }

                 }
             }catch (MalformedURLException e) {
                 e.printStackTrace();
             }
                  catch (IOException e) {
                     e.printStackTrace();
                 }
             return data;
         }

     }
     */
